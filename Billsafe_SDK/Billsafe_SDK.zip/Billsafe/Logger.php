<?php

interface Billsafe_Logger
{
    public function log($message);
}